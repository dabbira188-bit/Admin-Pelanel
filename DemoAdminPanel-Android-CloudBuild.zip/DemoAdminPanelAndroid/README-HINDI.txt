DEMO ADMIN PANEL - ANDROID PROJECT

Aapka uploaded inedex.html isi project mein app/src/main/assets/index.html ke naam se add kiya gaya hai.
Demo login (aapke HTML source ke mutabik):
Username: admin
Password: demo123

Yeh offline WebView demo hai. Manifest mein SMS, contacts, phone, call-log, gallery ya network permissions nahi hain.
HTML ke SMS / call-forwarding / Telegram screens sirf local preview hain; koi real SMS, call forwarding,
Telegram connection, device access, ya external data transfer nahi hota.

MOBILE SE APK BANANE KA TAREEQA (GitHub Actions):
1. GitHub par sign in karke New repository banayein.
2. Is ZIP ko extract karke project ki saari files repository ke main branch mein upload karein.
   .github folder bhi upload hona chahiye.
3. Repository mein Actions tab kholein.
4. "Build Demo Admin Panel APK" workflow select karke Run workflow dabayein.
5. Build complete hone par run ke Artifacts section se DemoAdminPanel-debug-apk download karein.
6. ZIP artifact ko extract karein. Usmein app-debug.apk milega.

Note: Is project ZIP mein compiled APK nahi hai. APK GitHub ke cloud runner par build hoga.
